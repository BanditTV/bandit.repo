# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Bandit Fitness by Q:90/Bandit TV
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Q:90/Bandit TV
#------------------------------------------------------------
# Thanks to Udan for the Youtube Addon Template

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.banditfitness'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "FitnessBlender"
YOUTUBE_CHANNEL_ID_2 = "yaboymillhoy"
YOUTUBE_CHANNEL_ID_3 = "BeFiT"
YOUTUBE_CHANNEL_ID_4 = "ToneItUpcom"
YOUTUBE_CHANNEL_ID_5 = "TheFitnessMarshall"
YOUTUBE_CHANNEL_ID_6 = "Perfectfitnesstv"
YOUTUBE_CHANNEL_ID_7 = "runtasticFitness"
YOUTUBE_CHANNEL_ID_8 = "popsugartvfit"
YOUTUBE_CHANNEL_ID_9 = "Gymra1"
YOUTUBE_CHANNEL_ID_10 = "charliejames1975"
YOUTUBE_CHANNEL_ID_11 = "steadyhealth"
YOUTUBE_CHANNEL_ID_12 = "PLuXBhhMFw2iB24PErbQAxsK5EvTGH148K"
YOUTUBE_CHANNEL_ID_13 = "PLoCqkLAlxPzzMi-JBpraFscVbLXlOu4nv"
YOUTUBE_CHANNEL_ID_14 = "PL9vsk6jg0N5z5GTElne_dtwd3RUy7Ehjl"
YOUTUBE_CHANNEL_ID_15 = "sunderlandafc"
YOUTUBE_CHANNEL_ID_16 = "SWANSPLAYER"
YOUTUBE_CHANNEL_ID_17 = "spursofficial"
YOUTUBE_CHANNEL_ID_18 = "WatfordFCofficial"
YOUTUBE_CHANNEL_ID_19 = "OfficialAlbion"
YOUTUBE_CHANNEL_ID_20 = "UCCNOsmurvpEit9paBOzWtUg"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="FitnessBlender",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-60HgUrZsM18/AAAAAAAAAAI/AAAAAAAAAAA/EhMzQ6LTPOk/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Millhoy Fitness",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://yt3.ggpht.com/-OdXdQSVw5kM/AAAAAAAAAAI/AAAAAAAAAAA/ozCsziH0ZZU/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="befit",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-H6YodrSuTiQ/AAAAAAAAAAI/AAAAAAAAAAA/mcMy87MgLEI/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Tone It Up",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-THpwFd3Eyvw/AAAAAAAAAAI/AAAAAAAAAAA/H53He1Wi6tA/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The Fitness Marshall",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-MloR3K7KCSA/AAAAAAAAAAI/AAAAAAAAAAA/LFxE73ZB7fc/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Perfect fitness tv",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-xc9T8yyhtjU/AAAAAAAAAAI/AAAAAAAAAAA/X8LdarAC9Zs/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Runtastic Fitness",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-8HwQbazlHEE/AAAAAAAAAAI/AAAAAAAAAAA/xR6JpICwpuk/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="POPSUGAR Fitness",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://yt3.ggpht.com/-BsrLTcw7rsg/AAAAAAAAAAI/AAAAAAAAAAA/e7g-a22BudQ/s100-c-k-no/photo.jpg",
        folder=True )
 		
    plugintools.add_item( 
        #action="", 
        title="GymRa",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://yt3.ggpht.com/-P8EqM-wtzEU/AAAAAAAAAAI/AAAAAAAAAAA/vQQIEReUt3g/s100-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="BodyRock",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-79qJxGA4EhM/AAAAAAAAAAI/AAAAAAAAAAA/Nl9vF5phtUU/s100-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="steadyhealth",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-LJYmrbOWwss/AAAAAAAAAAI/AAAAAAAAAAA/vKqGjU_RhkE/s100-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="45 minute zumba/dance workout",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://rachelurquhart.files.wordpress.com/2013/02/zumbafitnesslogovert_color-052512.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="Gillian Micheals Workouts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://static-s.aa-cdn.net/img/ios/399841706/22ee0f404d135a9f1d5dbcc4ace1b6e7?v=1",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The 'My Sexy Valentine' Workout",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/-DQAbvRvgqho/AAAAAAAAAAI/AAAAAAAAAAA/P2o8x0G7TnU/s100-c-k-no/photo.jpg",
        folder=True )
		
run()


